# CLAUDE.md — Audit Automation Platform

## Contexte du projet

Ce projet automatise le processus d'audit d'un cabinet d'audit externe français. Le flux actuel est 100% manuel dans Excel et sujet à des erreurs de copier-coller. On remplace ce processus par un pipeline Python automatisé.

### Universalité

Le système fonctionne pour N'IMPORTE QUEL client disposant d'un FEC, quelle que soit la taille de l'entreprise, le secteur d'activité ou le logiciel comptable utilisé. Le mapping PCG dans `mapping_pcg.yaml` couvre exhaustivement TOUS les numéros de comptes possibles du Plan Comptable Général français (classes 1 à 7, ~300 préfixes). Tout numéro de compte trouvera un cycle d'audit et une classification bilan, sans intervention manuelle. Le système a été testé avec le client GILAC (270 comptes, industrie) mais est conçu pour fonctionner avec des FEC de toute taille (de la micro-entreprise aux groupes avec des milliers de comptes).

### Le flux métier (de A à Z)

1. **Réception du FEC** (.txt) — Fichier des Écritures Comptables, obligatoire en France (art. L.47 A LPF). Contient toutes les écritures comptables d'un exercice. Format : texte délimité (tab ou pipe), encodage variable (UTF-8, CP1252, Latin-1).
2. **Import et nettoyage** — Détection auto du séparateur et de l'encodage, conversion des montants (virgule française → point), ajout de la colonne Solde = Débit - Crédit.
3. **Construction de la balance générale** — Agrégation par CompteNum/CompteLib, somme des Débits, Crédits et Soldes. Contrôle : la somme de tous les soldes DOIT être = 0.
4. **Comparaison N vs N-1** — La balance N est comparée avec la balance de l'exercice précédent. Calcul des variations en valeur absolue (K€) et en pourcentage.
5. **Mapping par cycle d'audit** — Chaque compte est assigné à un cycle d'audit (A=Achats, V=Ventes, P=Personnel, etc.) selon le plan comptable général (PCG). Le mapping peut venir d'un fichier FM existant ou être déduit automatiquement par préfixe de compte.
6. **Génération des feuilles maîtresses** — Un fichier Excel avec : un sommaire, une balance comparative N vs N-1, et un onglet par cycle d'audit ventilant les comptes par Actif/Passif/Charges/Produits.
7. **Injection dans les templates de feuilles de travail** — Les templates du cabinet (un fichier .xlsx par cycle avec des sous-feuilles par procédure d'audit) sont copiés, renommés, et les placeholders (#NomClient, #DateClôture) sont remplacés. Les soldes sont injectés dans les cellules appropriées.

### Les 13 cycles d'audit

| Code | Nom | Exemples de comptes |
|------|-----|---------------------|
| C Propres | Capitaux propres | 101xxx, 106xxx, 120xxx |
| C PRC | Provisions pour risques et charges | 151xxx |
| F | Financement | 164xxx, 512xxx, 661xxx |
| I Incorp | Immobilisations incorporelles | 207xxx, 280xxx |
| I Corp | Immobilisations corporelles | 213xxx-218xxx, 281xxx |
| I Fi | Immobilisations financières | 261xxx, 274xxx, 275xxx |
| S | Stocks | 311xxx-397xxx, 713xxx |
| A | Achats (Fournisseurs) | 401xxx, 408xxx, 486xxx, 601xxx-629xxx, 681xxx |
| V | Ventes (Clients) | 411xxx-419xxx, 491xxx, 654xxx, 701xxx-709xxx |
| P | Personnel | 421xxx-438xxx, 641xxx-649xxx |
| E | État (fiscal/social) | 441xxx-449xxx, 631xxx-637xxx, 691xxx-699xxx |
| T | Autres créances/dettes | 461xxx-478xxx, 655xxx, 658xxx, 751xxx, 758xxx |
| X | Résultat exceptionnel | 671xxx-678xxx, 771xxx-778xxx |

### Les 18 colonnes standard du FEC

JournalCode, JournalLib, EcritureNum, EcritureDate (AAAAMMJJ), CompteNum, CompteLib, CompAuxNum, CompAuxLib, PieceRef, PieceDate, EcritureLib, Debit, Credit, EcritureLet, DateLet, ValidDate, Montantdevise, Idevise

### Classification Actif/Passif/Charges/Produits

- Classe 1 (10x-15x) → Passif (capitaux propres, provisions, emprunts)
- Classe 2 (20x-29x) → Actif (immobilisations)
- Classe 3 (31x-39x) → Actif (stocks)
- Classe 4 → Mixte selon le préfixe :
  - 401-408 → Passif (fournisseurs créditeurs)
  - 409 → Actif (fournisseurs débiteurs)
  - 411-418 → Actif (clients débiteurs)
  - 419 → Passif (clients créditeurs)
  - 421-449 → Passif (dettes sociales/fiscales)
  - 486 → Actif (CCA)
  - 487 → Passif (PCA)
  - 491 → Actif (provisions dépréciation clients)
- Classe 5 (50x-59x) → Actif (trésorerie)
- Classe 6 → Charges
- Classe 7 → Produits

**Attention** : certains comptes changent de sens selon leur solde. Un compte 425 (Personnel avances) est normalement Actif mais peut être Passif s'il est créditeur. Le FM existant du client fait foi pour la classification — le mapping automatique par PCG est un fallback.

---

## Architecture du projet

```
audit-automation/
├── src/
│   ├── __init__.py
│   ├── parsers/
│   │   ├── __init__.py
│   │   ├── fec_parser.py          # Lecture et nettoyage du FEC
│   │   ├── balance_parser.py      # Lecture balance N-1 (Excel, CSV, FEC)
│   │   └── mapping_parser.py      # Extraction mapping depuis FM ou config
│   ├── engine/
│   │   ├── __init__.py
│   │   ├── controls.py            # Contrôles d'intégrité du FEC
│   │   ├── balance_builder.py     # Construction balance + comparaison N/N-1
│   │   └── cycle_mapper.py        # Ventilation des comptes par cycle
│   ├── writers/
│   │   ├── __init__.py
│   │   ├── styles.py              # Styles Excel centralisés (Design A)
│   │   ├── excel_writer.py        # Fichier de travail (FEC + BG N + BG N-1)
│   │   ├── fm_writer.py           # Feuilles maîtresses
│   │   └── template_writer.py     # Injection dans templates feuilles de travail
│   └── config/
│       ├── __init__.py
│       └── mapping_pcg.yaml       # Mapping PCG → cycles (configurable)
├── tests/
│   ├── __init__.py
│   ├── test_fec_parser.py
│   ├── test_controls.py
│   ├── test_balance_builder.py
│   ├── test_cycle_mapper.py
│   └── test_writers.py
├── data/                           # Fichiers de test (ne pas commiter)
│   ├── GILAC_2025_FEC.txt
│   ├── FM_GILAC.xlsx
│   └── templates/
│       ├── 20XX_XX_YYY_A_Fournisseurs-Achats.xlsx
│       └── ...
├── app.py                          # Interface Streamlit
├── main.py                         # CLI
├── requirements.txt
├── CLAUDE.md                       # Ce fichier
└── README.md
```

### Principes architecturaux

1. **Séparation stricte** — Les parsers lisent, le moteur calcule, les writers écrivent. Aucun module ne fait deux choses.
2. **Zéro duplication** — L'app Streamlit et le CLI appellent exactement les mêmes modules. Pas de copier-coller de logique.
3. **Config externalisée** — Le mapping PCG et les seuils d'alerte sont dans des fichiers YAML, pas en dur dans le code.
4. **Testable** — Chaque module a ses propres tests unitaires qui tournent avec les vrais fichiers dans `data/`.

---

## Spécifications détaillées par module

### src/parsers/fec_parser.py

**Input** : chemin ou file-like object vers un FEC .txt
**Output** : pandas DataFrame avec colonnes typées

Fonctionnalités :
- Détection automatique de l'encodage : tester UTF-8, CP1252, Latin-1 sur le fichier ENTIER (pas juste les premiers octets — certains FEC ont des caractères spéciaux en fin de fichier)
- Détection automatique du séparateur : tab (\t), pipe (|), point-virgule (;)
- Nettoyage : strip sur toutes les colonnes string, suppression des retours chariot Windows (\r)
- Conversion : Debit et Credit en float (virgule → point), Montantdevise en float
- Ajout : colonne Solde = Debit - Credit
- Validation : vérifier que les 18 colonnes obligatoires sont présentes

### src/parsers/balance_parser.py

**Input** : fichier Excel balance N-1, ou FEC N-1, ou FM existant
**Output** : dict {compte_num: {'libelle': str, 'solde_ke': float}}

Trois modes :
1. `from_fec(path)` — lit un FEC, construit la balance, convertit en K€
2. `from_excel(path)` — lit un Excel avec colonnes CompteNum, CompteLib, Solde
3. `from_fm(path)` — extrait les soldes N depuis l'onglet "Balance N Vs N-1" d'un FM existant

### src/parsers/mapping_parser.py

**Input** : FM existant (.xlsx) ou fichier mapping_pcg.yaml
**Output** : dict {compte_num: {'cycle': str, 'etatfi': str, 'compta': str}}

Deux sources :
1. `from_fm(path)` — lit l'onglet "Balance N Vs N-1" du FM, colonnes : B=CompteNum (int/float), C=CompteLib, H=Ref cycle, J=Cycle, K=EtatFi N, M=ComptaN
2. `from_pcg_config(path)` — lit le YAML de mapping par préfixe

### src/engine/controls.py

**Input** : DataFrame FEC, date de clôture
**Output** : liste de tuples (nom_controle, ok: bool, detail: str, severity: str)

Contrôles à implémenter :
- Équilibre Débit/Crédit (BLOQUANT si écart > 0.01)
- Colonnes obligatoires présentes
- Lignes à zéro (D=0 et C=0)
- Cohérence des dates (toutes dans l'exercice)
- Écritures un dimanche (WARNING)
- Montants ronds ≥ 10K€ (INFO)
- Doublons potentiels (même journal + même numéro + même compte + mêmes montants + même libellé)
- Test de Benford sur le premier chiffre des montants (distribution attendue vs observée, calcul du chi² et du MAD)
- Écritures passées tard (après le 31/01/N+1 si ValidDate disponible)

### src/engine/balance_builder.py

**Input** : DataFrame FEC, dict balance N-1
**Output** : DataFrame avec CompteNum, CompteLib, Debit, Credit, Solde, Solde_KE, Solde_N1_KE, Var_KE, Var_PCT

Fonctionnalités :
- Agrégation par CompteNum + CompteLib
- Conversion en K€ (÷ 1000)
- Calcul des variations vs N-1
- Var_PCT = 'n/a' si abs(N-1) < 0.001 (évite division par zéro)
- Vérification : somme des soldes = 0

### src/engine/cycle_mapper.py

**Input** : DataFrame balance, dict mapping existant, config YAML
**Output** : DataFrame balance enrichi avec colonnes cycle, compta, etatfi, ref

Logique de résolution (ordre de priorité) :
1. Si le compte existe dans le mapping du FM existant du client → utiliser ce mapping (priorité absolue)
2. Sinon → surcharges_cabinet du YAML (préfixes spécifiques au cabinet)
3. Sinon → chercher par préfixe dans le YAML, du plus spécifique au plus général :
   - Préfixe 3 chiffres (ex: "486" → A, "603" → S)
   - Préfixe 2 chiffres (ex: "48" → T, "60" → A)
   - Classe 1 chiffre — fallback garanti (ex: "6" → charges, "4" → T)
4. Le YAML couvre EXHAUSTIVEMENT le PCG français (classes 1-7). TOUT numéro de compte trouvera un match — il n'y a plus de fallback "T" arbitraire.
5. Classification Actif/Passif : utiliser la section classification_bilan du YAML pour la classe 4 (mixte). Classes 1 → Passif, 2-3-5 → Actif, 6 → Charges, 7 → Produits.

Le fichier mapping_pcg.yaml est structuré par classe (classe_1, classe_2, etc.). Le parser doit fusionner toutes les classes en un seul dict flat pour la résolution.

### src/writers/styles.py

**Design A — Minimaliste**. Zéro couleur de fond, hiérarchie par typographie seule.

Styles centralisés :
- `FONT_TITLE` : Arial 16, bold
- `FONT_SUBTITLE` : Arial 11, italic, color #808080
- `FONT_HEADER` : Arial 10, bold, color #808080
- `FONT_NORMAL` : Arial 10
- `FONT_BOLD` : Arial 10, bold
- `FONT_SECTION` : Arial 9, bold, color #999999 (pour les labels ACTIF/PASSIF/etc.)
- `FONT_META` : Arial 9, color #AAAAAA (pour les colonnes secondaires : Ref, Cycle, EtatFi)
- `BORDER_BOTTOM_MED` : trait medium noir (sous les en-têtes)
- `BORDER_BOTTOM_HAIR` : trait hairline #C0C0C0 (entre les lignes de données)
- `BORDER_TOP_THIN` : trait thin noir (au-dessus des totaux)
- `NUM_KE` : format `#,##0;(#,##0);"-"` — entiers, négatifs entre parenthèses, zéros = "-"
- `NUM_PCT` : format `0%` — pourcentages sans décimales

Fonctions utilitaires :
- `remove_gridlines(ws)` — supprime le quadrillage Excel
- `set_col_widths(ws)` — largeurs standard
- `write_header_row(ws, row, headers)` — en-tête avec trait épais
- `write_data_row(ws, row, ...)` — ligne de données avec trait fin
- `write_total_row(ws, row, ...)` — ligne total avec trait au-dessus, bold

**IMPORTANT** :
- Pas de PatternFill nulle part (aucune couleur de fond)
- Pas de datetime dans les en-têtes, uniquement des strings "31/12/2025"
- Montants arrondis à l'entier (pas de décimales), format K€
- Pas de couleur sur les variations (même significatives)

### src/writers/fm_writer.py

**Output** : fichier FM_{client}_{annee}.xlsx

Onglets à générer :
1. **Sommaire** — titre, nom client, date, liens vers les onglets
2. **Balance N Vs N-1** — tous les comptes triés par numéro, colonnes : Ref, CompteNum, CompteLib, Solde N, Solde N-1, Var K€, Var %, Ref cycle, Cycle, EtatFi N, EtatFi N-1, ComptaN, ComptaN-1
3. **Un onglet par cycle** (13 onglets) — nom du format "A0", "V0", "C_Propres0", etc. Même structure que la balance mais filtré par cycle, avec sous-sections ACTIF/PASSIF/CHARGES/PRODUITS et totaux par section

### src/writers/excel_writer.py

**Output** : fichier Travail_{client}_{annee}.xlsx

Onglets :
1. **FEC** — le FEC brut complet avec en-têtes stylés
2. **Balance N** — CompteNum, CompteLib, Débit, Crédit, Solde, Solde K€
3. **Balance N-1** — CompteNum, CompteLib, Solde K€

### src/writers/template_writer.py

**Output** : ZIP avec les 13 fichiers de feuilles de travail

Fonctionnalités :
- Copie chaque template, renomme (20XX_XX_YYY → {annee}_12_{client})
- Remplace #NomClient par le nom du client
- Remplace #DateClôture par la date au format JJ/MM/AAAA
- Supprime les quadrillages
- **Injection des soldes** : dans chaque feuille Synthèse, renseigner les soldes de la feuille maîtresse correspondante dans les cellules prévues

Mapping template → cycle :
- `A_Fournisseurs` → A
- `V_Clients` → V
- `P_Personnel` → P
- `E_Etat` → E
- `F_Financement` → F
- `S_Stocks` → S
- `T_Autres` → T
- `I_Immobilisations_corp` → I Corp
- `I_Immobilisations_incorporelles` → I Incorp
- `I_Immobilisations_financie` → I Fi
- `C_Capitaux` → C Propres
- `C_Provision` → C PRC
- `X_Re_sultat` → X

---

## Structure du FM existant (FM_GILAC.xlsx) — à utiliser comme référence

L'onglet "Balance N Vs N-1" a cette structure (row 8 = headers, data à partir de row 10) :

| Colonne | Index | Contenu |
|---------|-------|---------|
| A | 0 | Ref. (vide pour les lignes de données) |
| B | 1 | CompteNum (int ou float, ex: 101300) |
| C | 2 | CompteLib (string) |
| D | 3 | Solde N en K€ (float) |
| E | 4 | Solde N-1 en K€ (float) |
| F | 5 | Variation K€ |
| G | 6 | Variation % |
| H | 7 | Ref. cycle (ex: "C Propres0", "A0") |
| I | 8 | (vide) |
| J | 9 | Cycle (ex: "C Propres", "A", "V") |
| K | 10 | EtatFi N (ex: "Capital social", "Réserves") |
| L | 11 | EtatFi N-1 |
| M | 12 | ComptaN (ex: "Passif", "Actif", "Charges") |
| N | 13 | ComptaN-1 |

Les onglets cycle (A0, V0, etc.) ont la même structure avec en plus des sous-sections ACTIF/PASSIF/CHARGES/PRODUITS (label en colonne B, pas de données dans les colonnes numériques).

---

## Données de test (client GILAC — exemple, pas une limitation)

Ces données servent à tester le pipeline. Le système fonctionne avec n'importe quel FEC français.

- **FEC 2025** : 106 272 lignes, encodage CP1252, séparateur TAB, dates du 01/01/2025 au 31/12/2025
- **Balance 2025** : 270 comptes, équilibre parfait (écart = 0.00), résultat = -2 572 709 € (-2 573 K€)
- **Balance 2024 (N-1)** : 288 comptes (extraits du FM_GILAC existant qui couvre 2024 vs 2023)
- **29 nouveaux comptes en 2025** (absents du mapping 2024) : 106810, 231500, 401500, 401600, 409100, 411500, 411600, 445661, 455030, 486001, 512113, 512153, 512155, 604000, 607030, 611020, 616170, 621100, 622601, 623202, 623203, 637810, 641430, 649000, 671100, 758700, 762400, 767010, 768010
- **13 templates de feuilles de travail** avec entre 2 et 17 onglets chacun

---

## Commandes utiles

```bash
# Installer les dépendances
pip3 install -r requirements.txt

# Lancer les tests
python3 -m pytest tests/ -v

# Lancer le CLI
python3 main.py data/GILAC_2025_FEC.txt --client GILAC --date-cloture 31/12/2025 --n1-fm data/FM_GILAC.xlsx --templates data/templates/ --output output/

# Lancer l'interface Streamlit
python3 -m streamlit run app.py
```

---

## Règles de codage

- Python 3.9+ (compatibilité Mac du stagiaire)
- Type hints sur toutes les fonctions publiques
- Docstrings en français
- Pas de print() — utiliser le module logging
- Noms de variables en français pour le domaine métier (solde_ke, compte_num, cycle_audit)
- Noms techniques en anglais (parse, build, write, config)
- Chaque fonction fait une seule chose
- Pas de try/except silencieux — logger les erreurs
- Les DataFrames ne sont jamais modifiés en place — toujours retourner une copie

---

## Ordre de construction recommandé

1. `src/config/mapping_pcg.yaml` + `src/parsers/mapping_parser.py`
2. `src/parsers/fec_parser.py` + `tests/test_fec_parser.py`
3. `src/engine/balance_builder.py` + `tests/test_balance_builder.py`
4. `src/engine/controls.py` + `tests/test_controls.py`
5. `src/engine/cycle_mapper.py` + `tests/test_cycle_mapper.py`
6. `src/writers/styles.py`
7. `src/writers/excel_writer.py`
8. `src/writers/fm_writer.py`
9. `src/writers/template_writer.py` + `tests/test_writers.py`
10. `main.py` (CLI)
11. `app.py` (Streamlit)
12. Tests d'intégration end-to-end
